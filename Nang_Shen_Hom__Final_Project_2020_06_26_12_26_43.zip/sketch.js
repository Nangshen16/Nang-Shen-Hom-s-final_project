/*Nang Shen Hom's Final Project(LaGuardia TechHire*/
//borrow createSprite from github

/*create a virtual birthday card that causes an image of candles on a birthday cake and bouncing ball hit the cakes.
go out based upon an input that is blown upon*/
 //cake();
 //cake1();
 //cake2();
 //cake3();
 //cake4();


let xCandle = 45;
let xFire = 40;
let speed = 2;
//let gameOver;

function candle() {
  stroke(random(255));
  fill(255,0,0);
  ellipse(xFire,325,80,40);
  xFire = xFire + speed;
  
  noStroke()
  fill(90, 100, 90);
  rect(xCandle,300,100, 50 ,20, 20,20, 20);
}

//var bCake ;
var x = 45;
var y = 105;
var d = 50;
var x1= 40;
var y1= 115;
var w = 50;
var h = 40;
var x2 = 200;
var t = 20;
var w1 = 10;
let fl = 29;
let f2 = 15;
let z =  380;
let b = 0;

//game
var paddle;
var ball;
var wallTop;
var wallBottom;
var bounce;
var Max_SPEED;
var bounce;

//paddleA = createSprite(30, height/2 , 10, 100);
//paddleA.immovable = true;



//let bCake = 0;


let colr = 0;
let colg = 0;
let colb = 0;
let colc = 249;
let colc1= 228;
let colc2= 183;

  function setup() {
  createCanvas(600, 600);
    //drawball
    fill(random(colc2,colc));
  stroke(9);
  circle(100,z,40);
    //circle(mouseX,200,200,40);
    
    //z = z - 1 ;
    //move around
    //if ( z < 0) {
      //z = height;
    //}
    
  //background(colr,colg,colb);
    print("Happy Birthday");
    //colr = random(0,355);
    //ball = createSprite(width/2,height+30/2, width,30);
    //ball.maxSpeed = MAX_SPEED;
    //move the ball 
    //circle = circle + Max_SPEED;
}



   
      

function draw() {
  //background(colr,colg,colb);
  
  //drawing ball
  //fill(colr)
  //stroke(9)
  //circle(100,300,20);
  /*paddleA.position.y = constrain(mouseY, paddleA.height/2, height-paddleA.height/2);*/
  //drawcakeandfrost
  //fill(0);
  //stroke(9);
  //rect(40,405,90,100);
  //fill(0);
  //drawflame
  //fill(226,0,34);
  //flame
  stroke(random(425));
  //fill('#e25822');
  strokeWeight(5);
  ellipse(49,29,f2,25);
  
  //drawflame2
  fill(266,88,34);
  stroke(random(425));
  //fill('#e25822');
  //flame2
  strokeWeight(5);
  ellipse(183,29,f2,25);
  
  
  //flame3
  fill(266,88,34);
  stroke(random(425));
  ellipse(314,29,f2,25);
  
  
  //flame4
  ellipse(425,29,f2,25);
  //flame5
  ellipse(540,29,f2,25);
  
  //drawcandle
  fill(243,229,171);
  noStroke()
  rect(x,xCandle,w1,h);
  //cake
  fill(colc,colc1,colc2);
  noStroke();
  circle(x,y,d);
  textSize(30);
  text('HAP',72,t);
   //heart(550,95,50,1)
  //drawcandle
  fill(255,255,0);
  noStroke(9);
  rect(20,110,w,h);
  //function cake1
  
  
  //draw2ndcake
  //stroke(random(425));
  fill(244,194,194);
  noStroke()
  //strokeWeight(5);
  //ellipse(88,269,15,25);
  //fill(60,100,60);
  //candle2
  rect(178,xCandle,w1,h);
  
  fill(colc,colc1,colc2);
  noStroke();
  circle(180,y,d);
  //fill('#fae');
  textSize(30);
  text('PY',200,t);
  
  //drawlayer
  fill('#FFB6C1');
  noStroke();
  rect(155,y1,w,h);
 
   
   
  //draw3rdcake
  //fill(255,0,0);
  //fill('#EE82EE');
  noStroke();
  rect(310,xCandle,w1,h);
  fill(colc,colc1,colc2);
  noStroke();
  circle(310,y,d);
  text('B I R',315,t);
  
  //drawcakelayer3
  fill(255,0,0);
  noStroke();
  rect(285,y1,w,h);
   

  
  //draw4thcake
  rect(420,xCandle,w1,h);
  //ellipse(xFire,325,80,40);
  //drawfrost
  fill(colc,colc1,colc2);
  circle(420,y,d);
  text('T H',430,t);
  //cakelayer3
  fill(255,127,80);
  noStroke();
  rect(395,y1,w,h);

 
  
  //draw5thcakecandle
  fill(239,230,211);
  rect(535,xCandle,w1,h);
  
  //drawfrost
  fill(243,229,171);
  noStroke();
  circle(536,y,d);
  text('DAY',520,t);
  //drawlayer5
  fill(0,128,128);
  noStroke();
  rect(510,y1,w,h);
  
  
  //console.log('Game Over');
  
  
  
  
  //createbouncingball
  
  /*paddle.position.y = constrain (mouseY, paddle.height/2, height-paddleA.height/2);*/
  
  //ball.bounce(wallTop);
  //ball.bounce(wallBottom);
  
  //if (ball.position.x<0) {
    //ball.position.x = width/2;
    //ball.position.y = heighth/2;
    //ball.setSpeed(MAX_SPEED,0);}
  
  
  
  
  //function mousePressed() {
    //if(gameOver)
      //newGame();
    
}
//change background when mouse is clicked
   //function wall() {
     //if (mouseIsPressed) {
       //background(135,206,235);

  